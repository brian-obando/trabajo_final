function getProducts() {
    axios.get('/products')
      .then(function (response) {
        const productList = document.getElementById('productList');
        productList.innerHTML = '';
  
        response.data.forEach(function (product) {
          const productItem = document.createElement('div');
          productItem.innerHTML = `
            <p><strong>Código:</strong> ${product.codigo}</p>
            <p><strong>Nombre:</strong> ${product.nombre}</p>
            <p><strong>Descripción:</strong> ${product.descripcion}</p>
            <p><strong>Valor:</strong> ${product.valor}</p>
            <hr>
          `;
          productList.appendChild(productItem);
        });
      })
      .catch(function (error) {
        console.error(error);
      });
  }
  
  function createProduct() {
    const nombre = document.getElementById('nombre').value;
    const descripcion = document.getElementById('descripcion').value;
    const valor = parseFloat(document.getElementById('valor').value);
  
    const newProduct = { nombre, descripcion, valor };
  
    axios.post('/products', newProduct)
      .then(function (response) {
        console.log(response.data);
        getProducts();
      })
      .catch(function (error) {
        console.error(error);
      });
  }
  