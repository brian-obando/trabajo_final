const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

let products = [
  { codigo: 1, nombre: 'Producto 1', descripcion: 'Descripción del Producto 1', valor: 10.99 },
  { codigo: 2, nombre: 'Producto 2', descripcion: 'Descripción del Producto 2', valor: 20.99 },
];

// Obtener todos los productos
app.get('/products', (req, res) => {
  res.json(products);
});

// Obtener un producto por código
app.get('/products/:codigo', (req, res) => {
  const codigo = parseInt(req.params.codigo);
  const product = products.find((product) => product.codigo === codigo);

  if (product) {
    res.json(product);
  } else {
    res.status(404).json({ error: 'Producto no encontrado' });
  }
});

// Crear un nuevo producto

let nextCodigo = 3;

app.post('/products', (req, res) => {
    const { nombre, descripcion, valor } = req.body;
  
    const newProduct = { codigo: nextCodigo, nombre, descripcion, valor };
    products.push(newProduct);
    nextCodigo++;
  
    res.status(201).json(newProduct);
  });

// Actualizar un producto existente
app.put('/products/:codigo', (req, res) => {
  const codigo = parseInt(req.params.codigo);
  const { nombre, descripcion, valor } = req.body;

  const product = products.find((product) => product.codigo === codigo);

  if (product) {
    product.nombre = nombre;
    product.descripcion = descripcion;
    product.valor = valor;

    res.json(product);
  } else {
    res.status(404).json({ error: 'Producto no encontrado' });
  }
});

// Eliminar un producto
app.delete('/products/:codigo', (req, res) => {
  const codigo = parseInt(req.params.codigo);
  const index = products.findIndex((product) => product.codigo === codigo);

  if (index !== -1) {
    products.splice(index, 1);
    res.json({respuesta:'Producto eliminado'});
  } else {
    res.status(404).json({ error: 'Producto no encontrado' });
  }
});

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
  console.log('Servidor iniciado en http://localhost:3000');
});
